to run the code needs Visual studio community 2022 its necessiry to bew 2022
when installing in Workloads check on:1).Net desktop development 2)Desktop development then in installation details of Desktop development in left side check on the first 4 boxes: 1)MSVC 2)Windows 10/11 SDK 3)just in time debugger 4)c++ profiling tools
then switch from WorkLoads to Individual components scroll down till you find c++/CLI support install the latest version the in installation details in left side check the all boxes
then return back to WorkLoads and select Desktop development and check C++/CLI support its necessiry then press install
after installation reboot the pc

https://www.youtube.com/watch?v=HcxlYkU8aY0&list=PL2i17lRog5pBe7t9zJdFdugQ6bxgjntJD&ab_channel=Sciber
this is link installing the full program but dont forget vs community (2022) because in this video the vs version is 2019 """""its necessiry to be 2022 version""""""""".

then open project1.sln you can foun it in gui project with CLR winform (VS community 2022).rar then run and the gui will start i cant use our library in the header of the gui so i replaced it by Bitmap with the same algorithm typically.

there are a setup file you can setup the application and try it but may facing this error 0xc0000000007b if you facing it so run the gui from vs community 2022
or setup it on another pc and you can uninstall the application from the same setup file.





list of filters:
1-black and white
2-Gray scale
3-flip
4- image brightnes
5-detect edges
6-invert
7-sunlight
8-skew image
9-purple
10-resize
11-Merge
12-Old TV
13-Rotate
14-Blur
15-infrared
16-crop
17-Frame
18-sepiatone
19-cinematic
20-oil painting

2 new filters:
1-Sepiatone:
This filter gives the image more like a classic brown finish. You can imagine it as the old photographs from the last century.
2-cinematic:
This filter gives the image a colorful blossomy effect as it changes the primary colors of the image more toward pink and light blue.
